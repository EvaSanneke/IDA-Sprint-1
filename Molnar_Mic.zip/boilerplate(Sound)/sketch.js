let columns = 8;
let rows = 6;
let spaceX = 60;
let spaceY = 60;
let edgeX = 40;
let edgeY = 40;
let repetitions = 8;
let maxDistort = 25;
let palette = ["#16161B", "#D37139", "#C2042E", "#3C60AA", "#9A3E7D"];

// Sound
let micInstance;
let micLevel = { sum1: 0, sum2: 0, sum3: 0, sum4: 0 };

function setup() {
  createCanvas(600, 500);
  noFill();
  strokeWeight(1);

  micInstance = new Mic("Start Mic"); //Parameter übergibt Beschriftung des Buttons
}

function draw() {
  background(240);

  if (micInstance && micInstance.started) {
    /**
     * In jedem Frame wird die aktuelle Lautstärke erfragt
     * Werte die zurückkommen, gehen von 0 bis 255
     * allenfalls umwandeln
     */
    getMicLevel();
  }

  let hoveredColumn = floor(
    (micLevel.sum1 + micLevel.sum2 + micLevel.sum3 + micLevel.sum4) / 100
  );

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < columns; c++) {
      let startX = 50 + c * (spaceX + 4);
      let startY = r * spaceY + 50;

      let distance = abs(c - hoveredColumn);
      let distort = 0;

      if (distance <= 5) {
        distort = map(distance, 0, 5, maxDistort, 0);
      }

      for (let i = 0; i < repetitions; i++) {
        let x1 = startX + random(-distort, distort);
        let y1 = startY + random(-distort, distort);

        let x2 = startX + edgeX + random(-distort, distort);
        let y2 = startY + random(-distort, distort);

        let x3 = startX + edgeX + random(-distort, distort);
        let y3 = startY + edgeY + random(-distort, distort);

        let x4 = startX + random(-distort, distort);
        let y4 = startY + edgeY + random(-distort, distort);

        let chosenColor = random(palette);
        stroke(chosenColor);
        quad(x1, y1, x2, y2, x3, y3, x4, y4);
      }
    }
  }
}

async function getMicLevel() {
  micLevel = await micInstance.listenMic();
}
